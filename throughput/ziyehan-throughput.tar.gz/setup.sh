#!/bin/bash

docker build . -t JacksonThroughputServer

